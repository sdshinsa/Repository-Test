// enum declaration and function prototypes
#pragma once
#include "gwindow.h"

enum NumberType
{
	UNKNOWN,
	PRIME,
	COMPOSITE
};

// Function: drawSquare
// Purpose: Draws a 50x50 square 
// Input: A GWindow to draw the square, an int to display in the center of the square, a NumberType to determine what type of 
// number the square corresponds to which will also determine the color of the square, a double that represents the x coordinate 
// of the top - left corner of the square, and a double that represents the y coordinate of the top - left corner of the square
// Output: Nothing
void drawSquare(GWindow& gWindow, int numToDisplay, NumberType numType, double xTopLeft, double yTopLeft);

// Function: initVectors
// Purpose: To initialize vectors
// Input: A vector of ints and a vector of NumberType
// Output: Nothing
void initVectors(Vector<int>& primeTest, Vector<NumberType>& compositePrime);

// Function: drawGrid
// Purpose: To draw the current state of the grid
// Input: Gwindow, a vector of ints, a vector of NumberType
// Output: Nothing
void drawGrid(GWindow& gWindow, Vector<int>& primeTest, Vector<NumberType>& compositePrime);

// Function calcNextPrime
// Purpose: Finds the next prime number
// Input: A vector of ints, a vector of NumberTypes, the int to start testing at
// Output: An integer that is a prime number, if no prime numbers are found it will return -1
int calcNextPrime(Vector<int>& primeTest, Vector<NumberType>& compositePrime, int startAt);
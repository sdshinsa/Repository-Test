// Name: Stara Shinsato
// Email: sdshinsa@usc.edu
// ITP 365 Spring 2019
// HW1 - Sieve of Eratosthenes
// Platform: Windows

#include "gwindow.h"
#include "sieve.h"
#include "vector.h"
#include <iostream>

int main(int argc, char** argv)
{
	// Create a 500x500 window
	GWindow gw(500, 500);

	// vector of ints
	Vector<int> primeTest;
	Vector<NumberType> compositePrime;

	// initialize the vectors
	initVectors(primeTest, compositePrime);

	// draw a grid
	drawGrid(gw, primeTest, compositePrime);

	// calculate the next prime number and update the grid 
	int i = 2;
	int nextPrime;
	do
	{
		nextPrime = calcNextPrime(primeTest, compositePrime, i);
		drawGrid(gw, primeTest, compositePrime);
		pause(1000.0);
		i++;
	} while (nextPrime != -1);

	return 0;
}

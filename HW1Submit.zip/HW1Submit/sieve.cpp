// function implementations
#include "sieve.h"
#include <sstream>

void drawSquare(GWindow& gWindow, int numToDisplay, NumberType numType, double xTopLeft, double yTopLeft)
{
	// color of inside of rectangle based on number type
	if (numType == UNKNOWN)
	{
		gWindow.setColor("white");
	}
	if (numType == PRIME)
	{
		gWindow.setColor("green");
	}
	else if (numType == COMPOSITE)
	{
		gWindow.setColor("red");
	}
	
	// fill in the rectangle
	gWindow.fillRect(xTopLeft, yTopLeft, 50, 50);

	// set color of outline of rectangle
	gWindow.setColor("black");

	// draw the outline of the rectangle
	gWindow.drawRect(xTopLeft, yTopLeft, 50, 50);

	// use stream to convert the number to display into a string
	std::ostringstream stream;
	stream << numToDisplay;
	gWindow.drawLabel(stream.str(), xTopLeft + 25, yTopLeft + 25);

}

void initVectors(Vector<int>& primeTest, Vector<NumberType>& compositePrime)
{
	// add values to integer and NumberType vector 
	for (int i = 0; i < 100; i++)
	{
		primeTest.add(i + 2);
		compositePrime.add(UNKNOWN);
	}
}

void drawGrid(GWindow& gWindow, Vector<int>& primeTest, Vector<NumberType>& compositePrime)
{
	// start at upper left corner
	double x = 0.0;
	double y = 0.0;
	// draw 100 squares, 10 columns & 10 rows
	for (int i = 0; i < 100; i++)
	{
		// draw square at position (0, 0)
		drawSquare(gWindow, primeTest[i], compositePrime[i], x, y);
		// after the square is drawn when x = 450, move down a row
		if (x >= 450.0)
		{
			x = 0.0;
			y = y + 50.0;
		}
		else
		{
			x = x + 50.0;
		}
	}
}

int calcNextPrime(Vector<int>& primeTest, Vector<NumberType>& compositePrime, int startAt)
{
	// count how many unknowns to determine if there are still new prime numbers to be found
	int count = 0;
	for (int n = 0; n < 100; n++)
	{
		if (compositePrime[n] == UNKNOWN)
		{
			count = count + 1;
		}
	}
	// if no new prime numbers, end the function
	if (count == 0)
	{
		return -1;
	}
	// if there are new prime numbers, check for composite values
	else
	{
		// determine what index to start at
		int m = 0;
		for (int i = 0; i < 100; i++)
		{
			if (primeTest[i] == startAt)
			{
				m = i;
			}
		}
		for (m; m < 100; m++)
		{
			// make the first unknown value found prime
			if (compositePrime[m] == UNKNOWN)
			{
				compositePrime[m] = PRIME;
				// multiples of this prime number will be composite
				int l = 2;
				for (int k = 0; k < 100; k++)
				{
					if (primeTest[m] * l == primeTest[k])
					{
						compositePrime[k] = COMPOSITE;
						l++;
					}
				}
				return primeTest[m];
				break;
			}
		}
	}
}